HAMZAM — ABSENSI & GAJI APK

Penyimpanan data:
- HTML asli dipakai sebagai tampilan aplikasi.
- localStorage tetap diaktifkan melalui WebView DOM Storage.
- Data tersimpan di penyimpanan aplikasi Android.
- Data tetap ada saat aplikasi ditutup/dibuka kembali.
- Jangan memilih Hapus Data aplikasi atau mencopot instalasi jika ingin mempertahankan data.
- Saat update APK dengan applicationId yang sama, Android biasanya mempertahankan data aplikasi.

Build:
1. Upload seluruh isi folder proyek ini ke repository GitHub.
2. Jalankan GitHub Actions "Build HamZam APK".
3. Ambil artifact "HamZam-APK".
